package com.example.login_screen;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText username =findViewById(R.id.username);
        final EditText password =findViewById(R.id.password);
        Button login= findViewById(R.id.login);

        final Intent _intent = new Intent(this,NextPage_login.class);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (username.getText().toString().equals("harshil26") && password.getText().toString().equals("password")){

                    _intent.putExtra("username",username.getText().toString());
                    _intent.putExtra("password",password.getText().toString());
                    startActivity(_intent);
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Wrong username and password",Toast.LENGTH_SHORT).show();
                }
            }
        });



    }
}
