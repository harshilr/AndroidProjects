package com.example.login_screen;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class NextPage_login extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next_page_login);

        Intent _intent=getIntent();
        TextView textView =findViewById(R.id.textview);
        TextView textView1 =findViewById(R.id.textview1);

      String username = _intent.getStringExtra("username");
      String password =  _intent.getStringExtra("password");

      textView.setText(username);
      textView1.setText(password);
    }
}
